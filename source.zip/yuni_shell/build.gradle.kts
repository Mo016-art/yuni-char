// 根构建文件。本地用 Android Studio 打开即可；
// 云编译时 .github/workflows/build.yml 会现生成 gradle-wrapper.jar + gradlew。
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
