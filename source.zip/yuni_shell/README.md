# yuni phone · 原生壳骨架（B 方案）

把 `yuni_phone_v1944_先核有没有越界.html` 装进一个**自写 Kotlin WebView 壳**，而不是用 webtoAPP 这类一键打包器。一键工具只给 WebView + 推送 + 图标，不会附带无障碍服务、悬浮窗、应用锁这些原生组件。

> 这是**可编译骨架 + 设置页**，不是成品 App。沙盒里没有 Android SDK，未做真机编译 / 授权联调；语法与 Manifest 已做静态自检，真机第一次跑请按「已如实说」那节逐项核。

> **没有电脑也能用**：工程自带 `.github/workflows/build.yml`，手机浏览器上传
> `source.zip` 就能云编译出 apk；交付包里的《手机操作说明.md》是逐步操作卡。
> 而且装好之后**改 HTML 不再需要编译**——见下面「聊天页来源」。

---

## 三步接上你的 HTML

1. 把 `yuni_phone_v1944_先核有没有越界.html` 复制/覆盖为
   `app/src/main/assets/chat.html`（作为内置兜底）。
   **聊天页一行都不用改。**
2. 编译：有电脑就 Android Studio 打开本目录 Run；没电脑走云编译
   （见《手机操作说明.md》）。`minSdk 26 / targetSdk 35 / compileSdk 35`。
3. 首次打开后：进 `settings.html` → 逐项「去开启」授权 → 打开「启用 char 守护」→ 保存。

### 聊天页来源（不用电脑的关键）

`MainActivity` 把「手机里选中的 HTML」注册成 `WebViewAssetLoader` 的
`/user/chat.html` 虚拟路径，**origin 仍是 `https://appassets.androidplatform.net`**，
所以 `addWebMessageListener` 的白名单不用改，`YPNative` 照常注入。

- `pickHtml` → `ACTION_OPEN_DOCUMENT` 选文件 + `takePersistableUriPermission`
- `/user/` PathHandler 用 `ContentResolver` 读字节回给 WebView，禁缓存
- 文件失效自动清空偏好、回退内置页
- `reloadChat` 点一下即重读；`useBuiltinHtml` 恢复内置

于是你一版版改 HTML 时，只在手机上选一次文件，之后点「重新载入」即可，
**永远不用再编译 APK**。只有改 Kotlin / 权限 / 图标包名才需要重打包。

### 为什么聊天页不用改

v1943 已经预留了壳 Bridge：`window.YPNative.getBattery()`、
`window.__nativeBattery`、`ypbatterychange` 事件（原文件 L43865~L43944）。
壳在 `addDocumentStartJavaScript` 阶段注入 `window.YPNative`，并同步写入
`window.__nativeBattery = { level, pct, charging }`，值来自
`BatteryManager.BATTERY_PROPERTY_CAPACITY` + `ACTION_BATTERY_CHANGED`。
于是 `nativeProbe42()` 直接命中，`src` 标「真机」，电量条不再退回 50% 兜底。

WebView 不走 `file://`，改用 `WebViewAssetLoader` 的虚拟域
`https://appassets.androidplatform.net/assets/`，这样
`addWebMessageListener` 的 `allowedOriginRules` 才能只放行这一个源，
比 `addJavascriptInterface` 安全（后者会把 Java 对象暴露给所有 iframe）。

---

## 设置页对应你列的每一项

| 你的口径 | 落点 |
|---|---|
| 新增自启动行为 | `YpBootReceiver` + 「开机后恢复」开关 + 跳厂商自启动页 |
| 选择 char 开启 | `YpPrefs.charOn` 总闸，关掉即 `stopSelf()` |
| 读取所有引用 | `listApps` → 启动器可见应用列表，勾选写入管控名单 |
| 选择被管控 APP | `guardPkgs`，前台命中即处理 |
| char 锁 APP | `YpOverlayService` 全屏遮罩 + 解锁按钮 |
| 冻结时间 | `YpPrefs.Quota` 每 App 起止时段（支持跨午夜）+ `YpQuotaReceiver` 精确闹钟 |

另给了「规则式点击」：只允许你预先写死的「触发词 → 固定坐标」，默认关。

---

## Bridge 契约

JS 侧统一 `YPNative.call(cmd, args) -> Promise`；原生侧 `YpBridge.handle()` 分发。

**命令**：`ping` `getStatus` `openPermission` `getPrefs` `setPrefs` `listApps`
`readScreen` `tapRule` `bubble` `notify` `unlock` `sendUserText` `scheduleQuota`
`goSettings` `goChat` `pickHtml` `useBuiltinHtml` `reloadChat`

**原生推给 JS 的事件**（`YPNative.on(ev, fn)`）：
`ready` `resume` `accConnected` `foreground` `screenText` `quotaTick` `tapRule`
`unlocked` `screenshot` `htmlPicked`

`YpBus` 是原生侧的事件总线：无障碍服务 / 悬浮服务 / 接收器都不持有 Activity，
只 `YpBus.emit()`，由 MainActivity 转成 `evaluateJavascript` 推回页面。

### 「实时发消息」这条链路怎么接

骨架**故意没有内置**「读屏 → 自动调模型 → 自动发消息」，因为那等于把别的 App
屏幕原文默认外发。三段挂点都留好了，你自己决定接哪一段：

- **读屏**：`foreground` 变化时同时推 `screenText`（控件文本，最多 2000 字，
  文本不变不重复推），只到本地 WebView，不自动出网。
- **char 回复**：在你的聊天页拿到回复文本后调一次
  `YPNative.bubble(text)`（悬浮气泡）或 `YPNative.notify(text)`（系统通知）。
  这两条即使悬浮窗被 ROM 收掉也还有通知兜底。
- **自动触发**：若确实要「看到某页面就让 char 说话」，在前端
  `N.on('screenText', ...)` 里先做**应用白名单 + 脱敏**，再喂给你的接口；
  别把整屏原文直接拼进 prompt。

`readScreen` 命令与 `screenText` 事件都只返回控件文本，不是整屏截图原文。

---

## 权限：全部要用户手开，App 内不造假开关

| 权限 | 用途 | 系统页 |
|---|---|---|
| `BIND_ACCESSIBILITY_SERVICE` | 读控件文字 / 规则点击 / 前台识别 | 设置 → 无障碍 |
| `SYSTEM_ALERT_WINDOW` | 悬浮气泡 + 锁屏遮罩 | 显示在其他应用上层 |
| `PACKAGE_USAGE_STATS` | 前台识别的合规兜底 | 使用情况访问 |
| `POST_NOTIFICATIONS` | 前台服务常驻通知 | 应用通知 |
| `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` | 防 ROM 杀后台 | 电池优化白名单 |
| `SCHEDULE_EXACT_ALARM` | 冻结时段起止点 | 精确闹钟 |
| `RECEIVE_BOOT_COMPLETED` | 开机恢复 | 清单声明即可 |
| `QUERY_ALL_PACKAGES` | 应用列表 | 见下方降级说明 |

`autoStart` 状态固定返回 `unknown`——国产 ROM 没有标准查询 API，也没有静默开启 API，
设置页只做「跳厂商页 / 跳应用详情页」引导。

---

## 硬边界（别在业务层假装不存在）

1. **FLAG_SECURE**：银行 / 支付 / 密码窗口截图黑屏或回调
   `ERROR_TAKE_SCREENSHOT_SECURE_WINDOW`，无合规绕过。
2. **Android 14+**：`accessibilityDataSensitive` 视图只放行声明
   `isAccessibilityTool=true` 的服务。本服务按政策**不能**那样声明，读屏会缺块。
3. **Android 16+**：敏感视图连 `dispatchGesture` 注入手势一起挡；通话中也限制授予无障碍权限。
4. **Android 17 高级保护**：只放行系统已验证的无障碍工具。
5. **读屏不等于读懂**：Flutter / 游戏 / 自绘界面节点常为空，骨架只返回控件文本，
   没接 OCR（接了也要先解决第 1 条）。`YpAccessibilityService.screenshot()` 留了挂点。
6. **真冻结做不到**：停用 / 隐藏 / 暂停应用包需要 Root、Shizuku(adb) 或
   Device Owner（Dhizuku / Insular）。本壳的「冻结」= 定时拒绝打开 + 弹遮罩。
7. **自启动不可代码开**：安装后从未打开、或被「强行停止」的 App 收不到开机广播；
   小米 / 华为 / OPPO / vivo 白名单必须手开。
8. **后台保活不保证**：前台服务 + `START_STICKY` + 白名单仍可能被省电策略收掉，
   所以 `notify` 额外走一条系统通知兜底。Android 12+ 还限制从后台启动前台服务，
   若真机上「命中管控但遮罩不弹」，让守护服务保持常驻（charOn 时 MainActivity 已
   `startForegroundService`），或改成先发一条通知再拉起。
9. **目标 App 可以主动藏掉你的遮罩**：Android 12+ 应用声明
   `HIDE_OVERLAY_WINDOWS` 并调用 `setHideOverlayWindows(true)` 后，第三方 overlay
   在它的窗口上会被隐藏；`filterTouchesWhenObscured` 也会拒收被遮挡的触摸。
   锁屏遮罩在部分金融 / 系统界面上不出现是预期行为，不是 bug。

---

## 商店合规（自用侧载可跳过）

- Google Play **明确禁止**「自主发起、规划并执行操作或决策」的无障碍用途，
  只放行确定性的、人预先定死的规则（If X 则 Y）。骨架的 `tapRule` 就是这个形态，
  **没有**提供 char 自己决定点哪里的入口。
- 助手 / 自动化 / 监控 / 应用锁类 App **不具备** `isAccessibilityTool` 资格，
  虚报会拒审或被 Play Protect 拦；还得做应用内显著披露 + 单独同意 + 提交权限申报表。
- `QUERY_ALL_PACKAGES` 对普通工具类几乎必拒。上架时删掉该声明，
  改用 `<queries>` 按需可见性 + `UsageStatsManager` 只取当前前台包名——
  应用锁本来也不需要遍历全盘。
- `canTakeScreenshot="true"` 会显著抬高审核门槛，上架建议删这一行，只留控件文本。
- 悬浮窗 + 无障碍 + 全盘列表 + 自动点击是银行木马的典型静态特征组合，
  建议自用侧载或走国内渠道，别上 Play。

---

## 已如实说 / 下一步

- 未跑真机、未接 SDK 编译。`main.executor`、`unsafeCheckOpNoThrow`、
  厂商自启动页 component 名这些随 ROM 变化的地方，第一次联调要按 logcat 修。
- 锁屏遮罩目前是「点按钮即解锁」，正式用应接 `BiometricPrompt`（`USE_BIOMETRIC`）。
- `readScreen` 返回的是**缓存的控件文本**，不是整屏原文外发；
  若要喂给聊天接口，请先做本地白名单过滤 + 脱敏，别整屏发给模型侧。
- 冻结时段轮询是 60 秒一次 + 精确闹钟双保险；要秒级可把 `poll` 间隔调小，代价是耗电。
- 规则式点击的 `sendUserText` 只是挂点，要不要在你 `triggerReply` 里调一次由你定；
  不调也完全不影响聊天主流程。
- 想接真冻结：把 `YpQuotaReceiver` 换成 Shizuku / Dhizuku 调用
  `setApplicationHiddenSettingAsUser` 或 `pm suspend`，那是另一套授权模型。

## 没有电脑怎么编译

`.github/workflows/build.yml` 做的事：

1. 检查仓库里有没有 `source.zip`（只建 workflow 那次会跳过，不是失败）
2. 解压，用 `find` 找到 `settings.gradle.kts` 所在目录（zip 带不带外层都行）
3. JDK 17 + `setup-android` + `sdkmanager` 装 `android-35` / `build-tools;35.0.0`
4. `gradle/actions/setup-gradle` 装 Gradle 8.9
5. **云端现生成 wrapper**（`gradle wrapper`）——源码 zip 里不需要
   `gradle-wrapper.jar`，那个二进制在手机上也生成不出来
6. `./gradlew assembleDebug` → `upload-artifact` 出 `app-debug.apk`

debug 签名自用足够；Artifact 保留 14 天。手机端完整步骤见交付包里的
《手机操作说明.md》。

## 目录

```
yuni_shell/
├── settings.gradle.kts / build.gradle.kts / gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
├── .github/workflows/build.yml      ← 云编译
├── app/build.gradle.kts / proguard-rules.pro
├── README.md
└── app/src/main/
    ├── AndroidManifest.xml
    ├── res/xml/accessibility_service_config.xml
    ├── res/values/strings.xml
    ├── assets/  chat.html（放你的 HTML）· settings.html · yp_native_glue.js
    └── java/com/yuni/phone/shell/
        YpApp.kt · MainActivity.kt · YpBridge.kt · YpBus.kt · YpPrefs.kt
        YpAccessibilityService.kt · YpOverlayService.kt
        YpBootReceiver.kt · YpQuotaReceiver.kt · YpPermission.kt
```
