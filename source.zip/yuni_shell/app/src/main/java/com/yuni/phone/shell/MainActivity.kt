package com.yuni.phone.shell

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject
import java.io.ByteArrayInputStream

/**
 * 没有电脑也能一直用：聊天页可以从「手机里选的 HTML 文件」加载。
 *
 * 关键 trick：外部文件不走 file:// 也不走 loadDataWithBaseURL，
 * 而是注册成 WebViewAssetLoader 的 /user/ 虚拟路径。
 * 这样 origin 仍是 https://appassets.androidplatform.net，
 * addWebMessageListener 的 allowedOriginRules 不用改，YPNative 照常注入。
 * 你改一版 HTML → 在设置页点「重新载入」即可，永远不用重新编译 APK。
 */
class MainActivity : Activity() {

    companion object {
        private const val REQ_PICK_HTML = 7101
        const val DOMAIN = "appassets.androidplatform.net"
    }

    private lateinit var web: WebView
    private lateinit var bridge: YpBridge

    @Volatile
    private var assetLoader: WebViewAssetLoader? = null
    private var pendingHtmlCb: ((String?) -> Unit)? = null

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val lvl = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val pct = if (scale > 0 && lvl >= 0) lvl * 100 / scale else 50
            val charging = st == BatteryManager.BATTERY_STATUS_CHARGING ||
                st == BatteryManager.BATTERY_STATUS_FULL
            bridge.pushBattery(pct, charging)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        web = WebView(this)
        setContentView(web)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true          // 你 HTML 里的 IndexedDB / localStorage 需要
            databaseEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
        }

        rebuildLoader()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = assetLoader?.shouldInterceptRequest(request.url)
        }

        bridge = YpBridge(this, web, bootBattery())
        bridge.install()
        YpBus.attach { ev, data -> bridge.push(ev, data) }

        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))

        if (YpPrefs.isCharOn(this)) {
            ContextCompat.startForegroundService(this, Intent(this, YpOverlayService::class.java))
        }

        web.loadUrl(chatUrl())

        // 从系统无障碍设置页返回时刷新授权状态
        YpBus.emit("ready", YpPermission.snapshot(this))
    }

    override fun onResume() {
        super.onResume()
        YpBus.emit("resume", YpPermission.snapshot(this))
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(batteryReceiver) }
        YpBus.detach()
        super.onDestroy()
    }

    // ---------------- 聊天页来源 ----------------

    /** 外部 HTML 字节；失效（文件被删 / 权限被收回）就自动回退内置页。 */
    private fun readUserHtml(): ByteArray? {
        val s = YpPrefs.chatUri(this)
        if (s.isBlank()) return null
        return try {
            val uri = Uri.parse(s)
            contentResolver.openInputStream(uri)?.use { it.readBytes() }?.takeIf { it.isNotEmpty() }
                ?: run {
                    YpPrefs.setChatUri(this, "")
                    null
                }
        } catch (e: Exception) {
            YpPrefs.setChatUri(this, "")
            null
        }
    }

    private fun rebuildLoader() {
        val bytes = readUserHtml()
        assetLoader = WebViewAssetLoader.Builder()
            .setDomain(DOMAIN)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .addPathHandler("/user/", WebViewAssetLoader.PathHandler { path ->
                if ((path == "chat.html" || path.endsWith("/chat.html")) && bytes != null) {
                    val resp = WebResourceResponse("text/html", "utf-8", ByteArrayInputStream(bytes))
                    // 只禁缓存：改完 HTML 点「重新载入」就能立刻生效。
                    // 不加 CSP —— 原聊天页有大量 inline script / eval，额外限制反而会把它弄坏；
                    // 安全边界由 addWebMessageListener 的 origin 白名单守住。
                    resp.setResponseHeaders(mapOf("Cache-Control" to "no-store"))
                    resp
                } else null
            })
            .build()
    }

    fun chatUrl(): String =
        if (YpPrefs.chatUri(this).isBlank()) YpBridge.ORIGIN + "/assets/chat.html"
        else YpBridge.ORIGIN + "/user/chat.html"

    fun reloadChat() {
        rebuildLoader()
        web.post {
            web.clearCache(true)
            web.loadUrl(chatUrl())
        }
    }

    /** 由 YpBridge 的 pickHtml 命令触发；结果回到 onActivityResult。 */
    fun pickHtml(cb: (String?) -> Unit) {
        pendingHtmlCb = cb
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"                       // 国产文件管理器常不认 text/html，放宽
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("text/html", "text/plain", "application/octet-stream"))
        }
        runCatching {
            startActivityForResult(Intent.createChooser(i, "选聊天页 HTML"), REQ_PICK_HTML)
        }.onFailure {
            pendingHtmlCb = null
            cb(null)
        }
    }

    fun useBuiltinHtml(): Boolean {
        YpPrefs.setChatUri(this, "")
        reloadChat()
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK_HTML) return
        val uri = if (resultCode == RESULT_OK) data?.data else null
        val picked = uri?.toString()
        if (uri != null) {
            runCatching {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
            YpPrefs.setChatUri(this, uri.toString())
            reloadChat()
        }
        YpBus.emit("htmlPicked", JSONObject().put("uri", picked ?: "").put("ok", uri != null))
        pendingHtmlCb?.let { cb ->
            pendingHtmlCb = null
            runOnUiThread { cb(picked) }
        }
    }

    /** documentStart 脚本跑之前就要有值，所以随脚本一起注入，不等广播。 */
    private fun bootBattery(): JSONObject {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val pct = runCatching {
            bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        }.getOrDefault(50).coerceIn(0, 100)
        val sticky = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val st = sticky?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return JSONObject()
            .put("level", pct / 100.0)
            .put("pct", pct)
            .put("charging", st == BatteryManager.BATTERY_STATUS_CHARGING ||
                st == BatteryManager.BATTERY_STATUS_FULL)
    }
}
