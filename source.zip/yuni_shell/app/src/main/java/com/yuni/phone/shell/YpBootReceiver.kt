package com.yuni.phone.shell

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/**
 * 自启动行为：只有「选择 char 开启」+「允许开机恢复」两个开关都开时才拉起守护。
 *
 * 如实说明三个系统限制（代码绕不过，设置页也不做假开关）：
 * · 安装后从没打开过、或在系统设置里被「强行停止」的 App，收不到 BOOT_COMPLETED；
 * · 小米/华为/OPPO/vivo 的厂商自启动白名单必须用户手动开，没有统一 API；
 * · 电池优化 / 省电模式仍可能把前台服务杀掉，需引导加入白名单。
 */
class YpBootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_LOCKED_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED
        ) return
        if (!YpPrefs.isCharOn(c) || !YpPrefs.isAutoStartOn(c)) return
        ContextCompat.startForegroundService(
            c, Intent(c, YpOverlayService::class.java).setAction(YpOverlayService.ACTION_BOOT)
        )
        YpQuotaReceiver.reschedule(c)
    }
}
