package com.yuni.phone.shell

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.AlarmManager
import android.app.AppOpsManager
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import org.json.JSONObject

/** 权限状态查询 + 跳系统设置页。App 内一律不声称「已用代码帮你开启」。 */
object YpPermission {

    fun snapshot(c: Context): JSONObject = JSONObject()
        .put("accessibility", accessibilityEnabled(c))
        .put("accConnected", YpAccessibilityService.instance != null)
        .put("overlay", Settings.canDrawOverlays(c))
        .put("usage", usageGranted(c))
        .put("notifications", notificationsGranted(c))
        .put("battery", batteryIgnored(c))
        .put("exactAlarm", exactAlarmAllowed(c))
        // 厂商自启动没有标准查询 API，只能给 unknown，由用户去系统设置里确认
        .put("autoStart", "unknown")
        .put("charOn", YpPrefs.isCharOn(c))

    private fun accessibilityEnabled(c: Context): Boolean = runCatching {
        val am = c.getSystemService(Context.ACCESSIBILITY_SERVICE)
            as android.view.accessibility.AccessibilityManager
        am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == c.packageName }
    }.getOrDefault(false)

    private fun usageGranted(c: Context): Boolean = runCatching {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName)
        }
        mode == AppOpsManager.MODE_ALLOWED
    }.getOrDefault(false)

    private fun notificationsGranted(c: Context): Boolean = runCatching {
        (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).areNotificationsEnabled()
    }.getOrDefault(false)

    private fun batteryIgnored(c: Context): Boolean = runCatching {
        (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)
    }.getOrDefault(false)

    private fun exactAlarmAllowed(c: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            runCatching {
                (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).canScheduleExactAlarms()
            }.getOrDefault(false)
        } else true

    /** 返回是否成功拉起设置页；autoStart 找不到厂商页时退回应用详情页。 */
    fun open(c: Context, key: String): Boolean = runCatching {
        val i = when (key) {
            "accessibility" -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            "overlay" -> Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + c.packageName)
            )
            "usage" -> Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            "notifications" -> Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(Settings.EXTRA_APP_PACKAGE, c.packageName)
            "battery" -> Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:" + c.packageName)
            )
            "exactAlarm" -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + c.packageName))
            } else null
            "autoStart" -> autoStartIntent(c)
            else -> null
        } ?: return false

        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (i.resolveActivity(c.packageManager) == null) {
            // 兜底：至少把用户送到本应用详情页
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:" + c.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(fallback)
            return true
        }
        c.startActivity(i)
        true
    }.getOrDefault(false)

    /** 国产 ROM 的自启动页没有统一 API，逐个试，试不到就交给上面的兜底。 */
    private fun autoStartIntent(c: Context): Intent? {
        val candidates = listOf(
            "com.miui.securitycenter" to "com.miui.permcenter.autostart.AutoStartManagementActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity",
            "com.huawei.systemmanager" to "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity",
            "com.coloros.safecenter" to "com.coloros.safecenter.permission.startup.StartupAppListActivity",
            "com.oppo.safe" to "com.oppo.safe.permission.startup.StartupAppListActivity",
            "com.vivo.permissionmanager" to "com.vivo.permissionmanager.activity.BgStartUpManagerActivity",
            "com.samsung.android.lool" to "com.samsung.android.sm.ui.battery.BatteryActivity"
        )
        for ((pkg, cls) in candidates) {
            val i = Intent().setClassName(pkg, cls)
            if (i.resolveActivity(c.packageManager) != null) return i
        }
        return null
    }
}
