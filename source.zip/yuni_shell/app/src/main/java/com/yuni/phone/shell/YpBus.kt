package com.yuni.phone.shell

import org.json.JSONObject

/**
 * 原生 → WebView 的事件总线。
 * 无障碍服务、悬浮服务、开机接收器都不持有 Activity 引用，只往这里 emit；
 * MainActivity 在页面存活时挂一个 sink，把事件 evaluateJavascript 推回 JS。
 */
object YpBus {
    @Volatile
    private var sink: ((event: String, data: JSONObject) -> Unit)? = null

    fun attach(s: (String, JSONObject) -> Unit) { sink = s }
    fun detach() { sink = null }

    fun emit(event: String, data: JSONObject = JSONObject()) {
        sink?.let { runCatching { it(event, data) } }
    }
}
