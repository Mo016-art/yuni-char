package com.yuni.phone.shell

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context

class YpApp : Application() {
    companion object {
        const val CHANNEL_ID = "yp_guard"
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "char 守护", NotificationManager.IMPORTANCE_LOW).apply {
                    description = "前台服务常驻通知；悬浮气泡不走这里"
                }
            )
        }
    }
}
