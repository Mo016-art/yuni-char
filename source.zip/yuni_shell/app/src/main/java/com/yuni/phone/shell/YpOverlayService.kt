package com.yuni.phone.shell

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import org.json.JSONObject

/**
 * 悬浮气泡 + 锁屏遮罩 + 冻结时段轮询，三者共用一个前台服务。
 * 只在「选择 char 开启」为真时运行；关掉主开关立即 stopSelf。
 */
class YpOverlayService : Service() {

    companion object {
        private const val NOTI_ID = 1001
        const val ACTION_BOOT = "yp.boot"
        const val ACTION_BUBBLE = "yp.bubble"
        const val ACTION_LOCK = "yp.lock"
        const val ACTION_UNLOCK = "yp.unlock"
        private const val EXTRA_TEXT = "text"
        private const val EXTRA_PKG = "pkg"

        fun start(c: Context) = ContextCompat.startForegroundService(
            c, Intent(c, YpOverlayService::class.java).setAction(ACTION_BOOT)
        )

        fun stop(c: Context) = c.stopService(Intent(c, YpOverlayService::class.java))

        fun bubble(c: Context, text: String) = ContextCompat.startForegroundService(
            c, Intent(c, YpOverlayService::class.java).setAction(ACTION_BUBBLE).putExtra(EXTRA_TEXT, text)
        )

        fun lock(c: Context, pkg: String, reason: String) = ContextCompat.startForegroundService(
            c, Intent(c, YpOverlayService::class.java).setAction(ACTION_LOCK)
                .putExtra(EXTRA_PKG, pkg).putExtra(EXTRA_TEXT, reason)
        )

        fun unlock(c: Context) = ContextCompat.startForegroundService(
            c, Intent(c, YpOverlayService::class.java).setAction(ACTION_UNLOCK)
        )

        fun notifyText(c: Context, text: String) {
            // 气泡之外再给一条系统通知：锁屏 / 悬浮窗被 ROM 收掉时还有一条路
            val pi = PendingIntent.getActivity(
                c, 0, Intent(c, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = Notification.Builder(c, YpApp.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_email)
                .setContentTitle("char")
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager)
                .notify(2001, n)
        }
    }

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var bubbleView: TextView? = null
    private var bubbleHide: Runnable? = null
    private var lockView: LinearLayout? = null
    private var lockedPkg = ""

    private val poll = object : Runnable {
        override fun run() {
            if (!YpPrefs.isCharOn(this@YpOverlayService)) { stopSelf(); return }
            // 冻结时段到点：给前端一个提示，锁的实际拦截面在 onAccessibilityEvent
            val frozen = YpPrefs.guardPkgs(this@YpOverlayService).filter {
                YpPrefs.isFrozenNow(this@YpOverlayService, it)
            }
            if (frozen.isNotEmpty()) {
                YpBus.emit("quotaTick", JSONObject().put("pkgs", org.json.JSONArray(frozen)))
            }
            main.postDelayed(this, 60_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(NOTI_ID, buildNotification())
        main.post(poll)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!YpPrefs.isCharOn(this)) { stopSelf(); return START_NOT_STICKY }
        when (intent?.action) {
            ACTION_BUBBLE -> showBubble(intent.getStringExtra(EXTRA_TEXT).orEmpty())
            ACTION_LOCK -> showLock(
                intent.getStringExtra(EXTRA_PKG).orEmpty(),
                intent.getStringExtra(EXTRA_TEXT).orEmpty()
            )
            ACTION_UNLOCK -> hideLock()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        main.removeCallbacks(poll)
        bubbleHide?.let { main.removeCallbacks(it) }
        hideLock()
        bubbleView?.let { runCatching { wm.removeViewImmediate(it) } }
        bubbleView = null
        bubbleHide = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, YpApp.CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(getString(R.string.fgs_title))
            .setContentText(getString(R.string.fgs_text))
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    // ---------------- 悬浮气泡 ----------------
    private fun showBubble(text: String) {
        if (text.isBlank()) return
        main.post {
            val tv = bubbleView ?: TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 14f
                setPadding(28, 18, 28, 18)
                setBackgroundColor(Color.argb(225, 20, 20, 20))
                typeface = Typeface.DEFAULT_BOLD
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 140 }
                runCatching { wm.addView(this, lp) }
            }.also { bubbleView = it }

            tv.text = text
            tv.visibility = View.VISIBLE
            // 只取消上一个气泡的隐藏计时，不能动 poll 的 60 秒轮询
            bubbleHide?.let { main.removeCallbacks(it) }
            val r = Runnable {
                bubbleView?.let { runCatching { wm.removeViewImmediate(it) } }
                bubbleView = null
                bubbleHide = null
            }
            bubbleHide = r
            main.postDelayed(r, 6000L)
        }
    }

    // ---------------- 锁屏遮罩 ----------------
    private fun showLock(pkg: String, reason: String) {
        if (lockView != null && lockedPkg == pkg) return
        hideLock()
        lockedPkg = pkg
        main.post {
            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setBackgroundColor(Color.argb(245, 250, 250, 250))
                isClickable = true      // 吃掉一切触摸，防止穿透到被锁应用
            }
            root.addView(TextView(this).apply {
                text = "🔒  char 把这里按住了"
                textSize = 20f
                setTextColor(Color.BLACK)
                gravity = Gravity.CENTER
            })
            root.addView(TextView(this).apply {
                text = reason + "\n" + pkg
                textSize = 13f
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER
                setPadding(24, 24, 24, 48)
            })
            root.addView(Button(this).apply {
                text = "解锁并继续"
                setOnClickListener {
                    // 这里接 BiometricPrompt（USE_BIOMETRIC）更稳，骨架先留按钮
                    hideLock()
                    YpBus.emit("unlocked", JSONObject().put("pkg", lockedPkg))
                }
            })

            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                PixelFormat.OPAQUE
            ).apply { dimAmount = 0.6f }
            runCatching { wm.addView(root, lp) }
            lockView = root
        }
    }

    private fun hideLock() {
        main.post {
            lockView?.let { runCatching { wm.removeViewImmediate(it) } }
            lockView = null
            lockedPkg = ""
        }
    }
}
