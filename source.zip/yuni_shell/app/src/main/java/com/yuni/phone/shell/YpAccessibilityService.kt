package com.yuni.phone.shell

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/**
 * 读屏 + 规则式点击 + 前台窗口识别。
 *
 * 三条硬边界（别在业务层假装不存在）：
 * 1) FLAG_SECURE 窗口（银行 / 支付 / 密码）截图直接黑屏，没有合规绕过；
 * 2) Android 14 起 accessibilityDataSensitive 视图只放行 isAccessibilityTool 服务，
 *    本服务按政策不能那样声明，读到的内容会缺块；Android 16 连注入手势一起挡；
 * 3) 本服务绝不提供「char 自己决定点哪里」的入口，点击只来自 YpPrefs 里
 *    用户预先写死的固定规则（YpPrefs.TapRule）。
 */
class YpAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: YpAccessibilityService? = null
            private set

        private const val MAX_CHARS = 12000
        private const val MAX_DEPTH = 40
        private const val EMIT_THROTTLE_MS = 400L
    }

    private val main = Handler(Looper.getMainLooper())
    private var lastPkg = ""
    private var lastEmitAt = 0L
    private var lastScreenPkg = ""
    private var lastScreenText = ""
    private var lastScreenEmitText = ""
    private var lastScreenEmitAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        YpBus.emit("accConnected", JSONObject().put("ok", true))
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg.isBlank() || pkg == packageName) return
        if (pkg == "com.android.systemui" || pkg.contains("inputmethod") || pkg.contains("launcher")) return

        // 缓存当前窗口文字，供 YpNative.readScreen() 同步取
        runCatching {
            lastScreenPkg = pkg
            lastScreenText = collectText(rootInActiveWindow)
        }

        val now = System.currentTimeMillis()
        if (pkg == lastPkg && now - lastEmitAt < EMIT_THROTTLE_MS) return
        lastPkg = pkg
        lastEmitAt = now

        val frozen = YpPrefs.isFrozenNow(this, pkg)
        YpBus.emit(
            "foreground",
            JSONObject()
                .put("pkg", pkg)
                .put("guarded", YpPrefs.isGuarded(this, pkg))
                .put("frozen", frozen)
        )

        // 实时读屏：只推给本地 WebView，绝不在这里自动调模型接口。
        // 要不要把这段文字喂给 char、先滤掉哪些 App，由前端 / 用户决定。
        val text = lastScreenText
        if (text != lastScreenEmitText && now - lastScreenEmitAt > 1500L) {
            lastScreenEmitText = text
            lastScreenEmitAt = now
            YpBus.emit(
                "screenText",
                JSONObject()
                    .put("pkg", pkg)
                    .put("text", text.take(2000))
                    .put("truncated", text.length > 2000)
            )
        }

        // 锁 APP：命中管控名单 → 全屏遮罩；冻结时段内额外显示原因
        if (YpPrefs.isCharOn(this) && YpPrefs.isLockOn(this) && YpPrefs.isGuarded(this, pkg)) {
            YpOverlayService.lock(this, pkg, if (frozen) "冻结时段内" else "这个应用已被 char 锁住")
        }
    }

    override fun onInterrupt() = Unit

    /** 同步返回当前窗口的控件文字；读不到就是读不到，不拿想象补。 */
    fun dumpScreen(): JSONObject {
        val text = runCatching { collectText(rootInActiveWindow) }.getOrElse { lastScreenText }
        return JSONObject()
            .put("ok", text.isNotBlank())
            .put("pkg", lastScreenPkg)
            .put("text", text)
            .put("truncated", text.length >= MAX_CHARS)
            .put("hint", "FLAG_SECURE / 敏感视图 / 自绘界面可能为空；不会用猜测补齐")
    }

    private fun collectText(root: AccessibilityNodeInfo?): String {
        if (root == null) return ""
        val sb = StringBuilder()
        walk(root, sb, 0)
        return sb.toString()
    }

    private fun walk(n: AccessibilityNodeInfo?, sb: StringBuilder, depth: Int) {
        if (n == null || depth > MAX_DEPTH || sb.length >= MAX_CHARS) return
        try {
            val t = n.text?.toString().orEmpty().trim()
            val cd = n.contentDescription?.toString().orEmpty().trim()
            if (t.isNotEmpty() || cd.isNotEmpty()) {
                val r = Rect()
                n.getBoundsInScreen(r)
                sb.append("[d").append(depth).append("] ")
                    .append(if (t.isNotEmpty()) t else cd)
                    .append(" @").append(r.centerX()).append(",").append(r.centerY())
                    .append(if (n.isClickable) " clickable" else "")
                    .append('\n')
            }
            for (i in 0 until n.childCount) {
                if (sb.length >= MAX_CHARS) break
                walk(runCatching { n.getChild(i) }.getOrNull(), sb, depth + 1)
            }
        } catch (e: Exception) {
            // 节点在遍历过程中被回收是常态，跳过即可
        }
    }

    /** 只由 YpPrefs.TapRule 调用；坐标来自用户填的固定值。 */
    fun tap(x: Float, y: Float, cb: (Boolean) -> Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) { cb(false); return }
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 60))
            .build()
        val ok = dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) = main.post { cb(true) }
                override fun onCancelled(g: GestureDescription?) = main.post { cb(false) }
            },
            main
        )
        if (!ok) cb(false)
    }

    // 截图/OCR 兜底挂点留到后续版本再接：
    // takeScreenshot 的回调签名随 API 变动，且 FLAG_SECURE 读不到，
    // 骨架先只走「控件文本」这一条确定能编译、能跑通的路。
}
