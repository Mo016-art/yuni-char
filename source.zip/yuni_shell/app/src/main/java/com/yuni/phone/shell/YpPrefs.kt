package com.yuni.phone.shell

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalTime

/**
 * 所有开关只写本机配置。系统级授权（无障碍 / 悬浮窗 / 使用情况 / 电池白名单 /
 * 厂商自启动）一律由 YpPermission 跳系统设置页让用户手开，这里不假装「代码能开」。
 */
object YpPrefs {
    private const val FILE = "yp_shell"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun isCharOn(c: Context) = sp(c).getBoolean("char_on", false)
    fun setCharOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("char_on", v).apply()

    /** 手机里选中的聊天页 HTML（SAF 持久授权 URI）；空 = 用 assets/chat.html */
    fun chatUri(c: Context) = sp(c).getString("chat_uri", "") ?: ""
    fun setChatUri(c: Context, uri: String) = sp(c).edit().putString("chat_uri", uri).apply()

    /** 自启动行为：只控制「收到 BOOT_COMPLETED 时是否拉起前台服务」 */
    fun isAutoStartOn(c: Context) = sp(c).getBoolean("auto_start", false)
    fun setAutoStartOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("auto_start", v).apply()

    fun isLockOn(c: Context) = sp(c).getBoolean("lock_on", true)
    fun setLockOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("lock_on", v).apply()

    fun isTapRuleOn(c: Context) = sp(c).getBoolean("tap_rule_on", false)
    fun setTapRuleOn(c: Context, v: Boolean) = sp(c).edit().putBoolean("tap_rule_on", v).apply()

    // ---------- 被管控应用（「读取所有引用」勾出来的名单） ----------
    fun guardPkgs(c: Context): Set<String> {
        val raw = sp(c).getString("guard_pkgs", "[]") ?: "[]"
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map { a.getString(it) }.toSet()
        } catch (e: Exception) { emptySet() }
    }

    fun setGuardPkgs(c: Context, pkgs: Collection<String>) =
        sp(c).edit().putString("guard_pkgs", JSONArray(pkgs.toList()).toString()).apply()

    fun isGuarded(c: Context, pkg: String) = pkg in guardPkgs(c)

    // ---------- 冻结时段 ----------
    data class Quota(val enabled: Boolean, val from: String, val to: String)

    fun quota(c: Context, pkg: String): Quota {
        val raw = sp(c).getString("quota_$pkg", "") ?: ""
        if (raw.isBlank()) return Quota(false, "22:30", "07:00")
        return try {
            val o = JSONObject(raw)
            Quota(o.optBoolean("enabled", false), o.optString("from", "22:30"), o.optString("to", "07:00"))
        } catch (e: Exception) { Quota(false, "22:30", "07:00") }
    }

    fun setQuota(c: Context, pkg: String, q: Quota) =
        sp(c).edit().putString(
            "quota_$pkg",
            JSONObject().put("enabled", q.enabled).put("from", q.from).put("to", q.to).toString()
        ).apply()

    /** 支持跨午夜，例如 22:30 → 07:00 */
    fun isFrozenNow(c: Context, pkg: String): Boolean {
        val q = quota(c, pkg)
        if (!q.enabled) return false
        return try {
            val a = LocalTime.parse(q.from)
            val b = LocalTime.parse(q.to)
            val now = LocalTime.now()
            if (a <= b) now >= a && now <= b else now >= a || now <= b
        } catch (e: Exception) { false }
    }

    // ---------- 规则式点击：只允许人预先写死的「触发词 → 固定坐标」 ----------
    // 明确不提供 char 自主决定点哪里、点几下的通用入口。
    data class TapRule(val trigger: String, val x: Int, val y: Int)

    fun tapRules(c: Context): List<TapRule> {
        val raw = sp(c).getString("tap_rules", "[]") ?: "[]"
        return try {
            val a = JSONArray(raw)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                TapRule(o.optString("trigger", ""), o.optInt("x", 0), o.optInt("y", 0))
            }
        } catch (e: Exception) { emptyList() }
    }

    fun setTapRules(c: Context, rules: List<TapRule>) {
        val a = JSONArray()
        rules.forEach { a.put(JSONObject().put("trigger", it.trigger).put("x", it.x).put("y", it.y)) }
        sp(c).edit().putString("tap_rules", a.toString()).apply()
    }

    fun findTapRule(c: Context, text: String): TapRule? =
        tapRules(c).firstOrNull { it.trigger.isNotBlank() && text.contains(it.trigger) }

    fun snapshot(c: Context) = JSONObject()
        .put("chatUri", chatUri(c))
        .put("chatExternal", chatUri(c).isNotBlank())
        .put("charOn", isCharOn(c))
        .put("autoStart", isAutoStartOn(c))
        .put("lockOn", isLockOn(c))
        .put("tapRuleOn", isTapRuleOn(c))
        .put("guardPkgs", JSONArray(guardPkgs(c).toList()))
        .put("tapRules", JSONArray().also { a ->
            tapRules(c).forEach { a.put(JSONObject().put("trigger", it.trigger).put("x", it.x).put("y", it.y)) }
        })
}
