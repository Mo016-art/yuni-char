package com.yuni.phone.shell

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId

/**
 * 冻结时段的起止点唤醒。
 * 注意：这里的「冻结」= 定时拒绝打开 / 弹锁屏遮罩，不是系统级的停用 / 隐藏 / 暂停包。
 * 真冻结要 Root、Shizuku(adb) 或 Device Owner（Dhizuku/Insular），普通 APK 做不到。
 */
class YpQuotaReceiver : BroadcastReceiver() {

    companion object {
        private const val REQ = 3001

        fun reschedule(c: Context) {
            val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) return

            val now = System.currentTimeMillis()
            var next = Long.MAX_VALUE
            for (pkg in YpPrefs.guardPkgs(c)) {
                val q = YpPrefs.quota(c, pkg)
                if (!q.enabled) continue
                listOf(q.from, q.to).forEach { hhmm ->
                    runCatching {
                        val t = LocalTime.parse(hhmm)
                        val ms = LocalDate.now().atTime(t).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
                        val candidate = if (ms > now + 1000) ms else ms + 24 * 3600_000L
                        if (candidate < next) next = candidate
                    }
                }
            }
            if (next == Long.MAX_VALUE) {
                am.cancel(pending(c)); return
            }
            val type = AlarmManager.RTC_WAKEUP
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(type, next, pending(c))
            } else {
                am.setExact(type, next, pending(c))
            }
        }

        private fun pending(c: Context): PendingIntent = PendingIntent.getBroadcast(
            c, REQ, Intent(c, YpQuotaReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    override fun onReceive(c: Context, intent: Intent?) {
        if (!YpPrefs.isCharOn(c)) return
        val frozen = YpPrefs.guardPkgs(c).filter { YpPrefs.isFrozenNow(c, it) }
        YpBus.emit("quotaTick", JSONObject().put("pkgs", org.json.JSONArray(frozen)))
        reschedule(c)   // 排下一个起止点
    }
}
