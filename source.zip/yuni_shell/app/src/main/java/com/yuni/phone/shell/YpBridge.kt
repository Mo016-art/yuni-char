package com.yuni.phone.shell

import android.app.Activity
import android.content.Intent
import android.webkit.WebView
import androidx.webkit.JavaScriptReplyProxy
import androidx.webkit.WebMessageCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject

/**
 * WebView ↔ 原生双向桥。
 *
 * 对外命名空间沿用你 HTML 里 v1943 已经埋好的 window.YPNative /
 * window.__nativeBattery / 'ypbatterychange'，所以聊天页一行都不用改，
 * 电量条会直接读到真机 BatteryManager 的值。
 *
 * 通信走官方推荐的 addWebMessageListener（带 allowedOriginRules 来源白名单），
 * 只有 https://appassets.androidplatform.net 这一个虚拟资源域能调到原生；
 * 不用老的 addJavascriptInterface，避免所有 iframe 都能拿到 Java 对象。
 */
class YpBridge(
    private val activity: Activity,
    private val web: WebView,
    private val bootBattery: JSONObject
) {
    companion object {
        const val ORIGIN = "https://appassets.androidplatform.net"
    }

    fun install() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.WEB_MESSAGE_LISTENER)) return

        WebViewCompat.addWebMessageListener(
            web, "YPNativeRaw", setOf(ORIGIN)
        ) { _, message, _, _, reply ->
            handle(message.data, reply)
        }

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            val boot = "window.__ypBootBattery=" + bootBattery.toString() + ";\n"
            WebViewCompat.addDocumentStartJavaScript(web, boot + INJECT_JS, setOf(ORIGIN))
        }
    }

    // ---------------- 原生 → JS ----------------
    fun push(event: String, data: JSONObject = JSONObject()) {
        web.post {
            val js = "window.__ypNativeEmit&&window.__ypNativeEmit(" +
                JSONObject.quote(event) + "," + data.toString() + ")"
            web.evaluateJavascript(js, null)
        }
    }

    fun pushBattery(pct: Int, charging: Boolean) {
        val o = JSONObject()
            .put("level", pct / 100.0)   // v1943：≤1 当 0~1 比例
            .put("pct", pct)             // v1943：pct 直接当百分数
            .put("charging", charging)
        web.post {
            web.evaluateJavascript(
                "window.YPNative&&window.YPNative.setBattery(" + o.toString() + ")", null
            )
        }
    }

    fun go(page: String) = web.post { web.loadUrl("$ORIGIN/assets/$page.html") }

    private fun goChat() = web.post {
        web.loadUrl((activity as? MainActivity)?.chatUrl() ?: "$ORIGIN/assets/chat.html")
    }

    // ---------------- JS → 原生 ----------------
    private fun handle(raw: String?, reply: JavaScriptReplyProxy) {
        val o = try { JSONObject(raw ?: "{}") } catch (e: Exception) { return }
        val id = o.optString("id", "")
        val cmd = o.optString("cmd", "")
        val a = o.optJSONObject("args") ?: JSONObject()

        try {
            when (cmd) {
                "ping" -> ok(reply, id, JSONObject().put("shell", true).put("version", "0.1-shell"))

                "getStatus" -> ok(reply, id, YpPermission.snapshot(activity))
                "openPermission" -> {
                    val key = a.optString("key", "")
                    ok(reply, id, JSONObject().put("opened", YpPermission.open(activity, key)))
                }

                "getPrefs" -> ok(reply, id, YpPrefs.snapshot(activity))
                "setPrefs" -> {
                    applyPrefs(a)
                    ok(reply, id, YpPrefs.snapshot(activity))
                }

                "listApps" -> ok(reply, id, JSONObject().put("apps", listApps()))
                "readScreen" -> ok(reply, id, readScreen())

                // 只认「用户预先写死的规则」，不接受前端传来的自由坐标
                "tapRule" -> tapByRule(reply, id, a.optString("trigger", ""))

                "bubble" -> {
                    YpOverlayService.bubble(activity, a.optString("text", ""))
                    ok(reply, id, JSONObject().put("sent", true))
                }
                "notify" -> {
                    YpOverlayService.notifyText(activity, a.optString("text", ""))
                    ok(reply, id, JSONObject().put("sent", true))
                }
                "unlock" -> {
                    YpOverlayService.unlock(activity)
                    ok(reply, id, JSONObject().put("unlocked", true))
                }

                // 前端把本轮 user 文字回传，命中规则才允许点击；char 不参与决策
                "sendUserText" -> {
                    val text = a.optString("text", "")
                    val rule = if (YpPrefs.isTapRuleOn(activity)) YpPrefs.findTapRule(activity, text) else null
                    if (rule != null) {
                        YpAccessibilityService.instance?.tap(rule.x.toFloat(), rule.y.toFloat()) { done ->
                            YpBus.emit("tapRule", JSONObject().put("trigger", rule.trigger).put("done", done))
                        }
                    }
                    ok(reply, id, JSONObject().put("matched", rule?.trigger ?: ""))
                }

                "scheduleQuota" -> {
                    YpQuotaReceiver.reschedule(activity)
                    ok(reply, id, JSONObject().put("scheduled", true))
                }

                "goSettings" -> { go("settings"); ok(reply, id, JSONObject()) }
                "goChat" -> { goChat(); ok(reply, id, JSONObject()) }

                // 没有电脑也能一直迭代：从手机里选 HTML，改完点重载即可
                "pickHtml" -> {
                    val act = activity as? MainActivity
                    if (act == null) fail(reply, id, "Activity 不可用")
                    else act.pickHtml { uri ->
                        ok(reply, id, JSONObject().put("uri", uri ?: "").put("ok", uri != null))
                    }
                }
                "useBuiltinHtml" -> {
                    val done = (activity as? MainActivity)?.useBuiltinHtml() ?: false
                    ok(reply, id, JSONObject().put("ok", done))
                }
                "reloadChat" -> {
                    (activity as? MainActivity)?.reloadChat()
                    ok(reply, id, JSONObject().put("ok", true))
                }

                else -> fail(reply, id, "unknown cmd: $cmd")
            }
        } catch (e: Exception) {
            fail(reply, id, e.message ?: "error")
        }
    }

    private fun applyPrefs(a: JSONObject) {
        a.optJSONObject("flags")?.let { f ->
            if (f.has("charOn")) YpPrefs.setCharOn(activity, f.optBoolean("charOn"))
            if (f.has("autoStart")) YpPrefs.setAutoStartOn(activity, f.optBoolean("autoStart"))
            if (f.has("lockOn")) YpPrefs.setLockOn(activity, f.optBoolean("lockOn"))
            if (f.has("tapRuleOn")) YpPrefs.setTapRuleOn(activity, f.optBoolean("tapRuleOn"))
        }
        a.optJSONArray("guardPkgs")?.let { arr ->
            YpPrefs.setGuardPkgs(activity, (0 until arr.length()).map { arr.getString(it) })
        }
        a.optJSONArray("quotas")?.let { arr ->
            for (i in 0 until arr.length()) {
                val q = arr.getJSONObject(i)
                YpPrefs.setQuota(
                    activity, q.optString("pkg"),
                    YpPrefs.Quota(q.optBoolean("enabled"), q.optString("from"), q.optString("to"))
                )
            }
        }
        a.optJSONArray("tapRules")?.let { arr ->
            YpPrefs.setTapRules(activity, (0 until arr.length()).map {
                val r = arr.getJSONObject(it)
                YpPrefs.TapRule(r.optString("trigger"), r.optInt("x"), r.optInt("y"))
            })
        }
        if (YpPrefs.isCharOn(activity)) YpOverlayService.start(activity) else YpOverlayService.stop(activity)
        YpQuotaReceiver.reschedule(activity)
    }

    private fun listApps(): JSONArray {
        val pm = activity.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = JSONArray()
        // QUERY_ALL_PACKAGES 可见全盘；上架时删除该权限后这里只剩 <queries> 声明的包，
        // 应用锁的前台识别会由 UsageStatsManager / 无障碍兜住，不依赖这份列表。
        for (ri in pm.queryIntentActivities(intent, 0)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == activity.packageName) continue
            val q = YpPrefs.quota(activity, pkg)
            out.put(
                JSONObject()
                    .put("pkg", pkg)
                    .put("label", ri.loadLabel(pm).toString())
                    .put("guarded", YpPrefs.isGuarded(activity, pkg))
                    .put("quotaEnabled", q.enabled)
                    .put("from", q.from)
                    .put("to", q.to)
                    .put("frozenNow", YpPrefs.isFrozenNow(activity, pkg))
            )
        }
        return out
    }

    private fun readScreen(): JSONObject {
        val svc = YpAccessibilityService.instance
            ?: return JSONObject().put("ok", false).put("reason", "无障碍服务未开启")
        return svc.dumpScreen()
    }

    private fun tapByRule(reply: JavaScriptReplyProxy, id: String, trigger: String) {
        if (!YpPrefs.isTapRuleOn(activity)) {
            fail(reply, id, "规则式点击未开启"); return
        }
        val rule = YpPrefs.tapRules(activity).firstOrNull { it.trigger == trigger && it.trigger.isNotBlank() }
            ?: run { fail(reply, id, "没有这条预置规则"); return }
        val svc = YpAccessibilityService.instance
            ?: run { fail(reply, id, "无障碍服务未开启"); return }
        svc.tap(rule.x.toFloat(), rule.y.toFloat()) { done ->
            ok(reply, id, JSONObject().put("done", done).put("trigger", trigger))
        }
    }

    private fun ok(reply: JavaScriptReplyProxy, id: String, data: Any?) {
        val j = JSONObject().put("id", id).put("ok", true)
        j.put("data", data ?: JSONObject.NULL)
        reply.postMessage(j.toString())
    }

    private fun fail(reply: JavaScriptReplyProxy, id: String, err: String) =
        reply.postMessage(JSONObject().put("id", id).put("ok", false).put("error", err).toString())

    /** 页面任何脚本跑之前注入；不用 addJavascriptInterface，源已被 WebView 校验过。 */
    private val INJECT_JS = """
(function () {
  if (window.YPNative) return;
  var raw = window.YPNativeRaw;
  if (!raw) return;
  var seq = 1, pending = {}, listeners = {};

  raw.onmessage = function (ev) {
    var r;
    try { r = JSON.parse(ev.data); } catch (e) { return; }
    if (r.id && pending[r.id]) {
      var p = pending[r.id]; delete pending[r.id];
      if (r.ok) p.resolve(r.data); else p.reject(new Error(r.error || 'native fail'));
      return;
    }
    if (r.event) {
      (listeners[r.event] || []).forEach(function (f) { try { f(r.data); } catch (e) {} });
    }
  };

  window.__ypNativeEmit = function (ev, data) {
    (listeners[ev] || []).forEach(function (f) { try { f(data); } catch (e) {} });
  };

  function call(cmd, args) {
    return new Promise(function (resolve, reject) {
      var id = 'c' + (seq++);
      pending[id] = { resolve: resolve, reject: reject };
      raw.postMessage(JSON.stringify({ id: id, cmd: cmd, args: args || {} }));
      // 选文件要用户去翻文件管理器，8 秒太短；其余命令仍按 8 秒兜底
      var to = (cmd === 'pickHtml') ? 60000 : 8000;
      setTimeout(function () {
        if (pending[id]) { delete pending[id]; reject(new Error('native timeout')); }
      }, to);
    });
  }

  var bat = window.__ypBootBattery || { level: 0.5, charging: false, pct: 50 };
  window.__nativeBattery = bat;          // v1943 nativeProbe42 直接读这个
  window.YPNativeBattery = bat;

  var N = {
    ready: true,
    version: '0.1-shell',
    call: call,
    battery: bat,
    getBattery: function () { return bat; },   // v1943 同步契约，返回对象或 Promise 都认
    setBattery: function (o) {
      bat = o; N.battery = o; window.__nativeBattery = o; window.YPNativeBattery = o;
      try { window.dispatchEvent(new CustomEvent('ypbatterychange', { detail: o })); } catch (e) {}
    },
    on: function (ev, fn) {
      (listeners[ev] = listeners[ev] || []).push(fn);
      return function () {
        listeners[ev] = (listeners[ev] || []).filter(function (x) { return x !== fn; });
      };
    },
    ping: function () { return call('ping'); },
    getStatus: function () { return call('getStatus'); },
    openPermission: function (key) { return call('openPermission', { key: key }); },
    getPrefs: function () { return call('getPrefs'); },
    setPrefs: function (o) { return call('setPrefs', o); },
    listApps: function () { return call('listApps'); },
    readScreen: function () { return call('readScreen'); },
    tapRule: function (trigger) { return call('tapRule', { trigger: trigger }); },
    bubble: function (text) { return call('bubble', { text: text }); },
    notify: function (text) { return call('notify', { text: text }); },
    unlock: function () { return call('unlock'); },
    sendUserText: function (text) { return call('sendUserText', { text: text }); },
    scheduleQuota: function () { return call('scheduleQuota'); },
    goSettings: function () { return call('goSettings'); },
    goChat: function () { return call('goChat'); },
    pickHtml: function () { return call('pickHtml'); },
    useBuiltinHtml: function () { return call('useBuiltinHtml'); },
    reloadChat: function () { return call('reloadChat'); }
  };
  window.YPNative = N;
})();
""".trimIndent()
}
