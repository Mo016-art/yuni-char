/* yp_native_glue.js — 可选接线示例
 * 复制到你自己 chat.html 的 </body> 前即可；不改原文件也能跑，只是没有这个面板。
 * 只负责把原生推来的事件渲染出来，不碰你原有的聊天 / 提示词逻辑。
 */
(function () {
  if (!window.YPNative) return;

  var box = document.createElement('div');
  box.setAttribute('data-yp-shell', '1');
  box.style.cssText = 'position:fixed;left:12px;bottom:12px;z-index:9998;max-width:72vw;' +
    'font:12px/1.5 -apple-system,"PingFang SC",sans-serif;background:rgba(17,17,17,.88);' +
    'color:#fff;padding:9px 12px;border-radius:10px;pointer-events:none;opacity:0;transition:.25s';
  document.addEventListener('DOMContentLoaded', function () {
    (document.body || document.documentElement).appendChild(box);
  });

  var timer;
  function say(s) {
    if (!box.parentNode) return;
    box.textContent = s;
    box.style.opacity = '1';
    clearTimeout(timer);
    timer = setTimeout(function () { box.style.opacity = '0'; }, 4200);
  }

  window.YPNative.on('foreground', function (d) {
    say('前台 ' + (d.pkg || '?') + (d.guarded ? ' · 已管控' : '') + (d.frozen ? ' · 冻结中' : ''));
  });
  window.YPNative.on('quotaTick', function (d) {
    say('冻结时段切换 · ' + ((d.pkgs || []).length) + ' 个应用');
  });
  window.YPNative.on('screenText', function (d) {
    // 只报长度，不把别的 App 的原文贴到悬浮层上
    say('读到 ' + (d.pkg || '?') + ' · ' + ((d.text || '').length) + ' 字（仅本地）');
  });
  window.YPNative.on('tapRule', function (d) {
    say('规则点击 ' + (d.trigger || '') + (d.done ? ' 完成' : ' 被系统拒绝'));
  });
  window.YPNative.on('unlocked', function () { say('锁已解开'); });
  window.YPNative.on('accConnected', function () { say('无障碍已连上'); });
  window.YPNative.on('screenshot', function (d) {
    say(d.ok ? '截图成功' : '截图被拒（FLAG_SECURE 不做绕过）');
  });

  // 若你想让本轮 user 文字参与「规则式点击」，在自己的发送函数里调一次：
  //   window.YPNative && window.YPNative.sendUserText(text);
  // 只有命中用户预先写死的规则才会点，char 不参与决策。
  window.YPShell = { say: say };
})();
