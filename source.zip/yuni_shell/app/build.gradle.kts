plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.yuni.phone.shell"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.yuni.phone.shell"
        minSdk = 26            // dispatchGesture 需 24+；takeScreenshot 需 30+（代码里按版本守卫）
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-shell"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.webkit:webkit:1.12.1")   // WebViewAssetLoader / addWebMessageListener
}
